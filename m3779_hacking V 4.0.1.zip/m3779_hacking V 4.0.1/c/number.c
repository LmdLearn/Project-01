int a = 1
int aa = 2
int aaa = 3
int aaaa = 4
int aaaaa = 5
int ab = 6
int aab = 7
int aaab = 8
int aaaab = 9
}
