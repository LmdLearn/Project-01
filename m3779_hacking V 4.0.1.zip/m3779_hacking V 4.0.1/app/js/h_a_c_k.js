{
var a = 1;
var aa = 2;
var aaa = 3;
var aaaa = 4;
var aaaaa = 5;
var ab = 6;
var aab = 7;
var aaab = 8;
var aaaab = 9;
}
function hacking(){
    
   var x = document.getElementById('gg').innerHTML="ریپورت شد";
};